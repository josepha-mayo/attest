#!/usr/bin/env python3
"""Verify Attest records offline. Stdlib only — no pip, no attest install.

Checks: payload sha256, envelope/payload agreement, Ed25519 signatures,
revision ordering, and anchoring to the original receipt. Media digests are
checked against files inside the pack.
"""
import base64
import hashlib
import json
import sys
from pathlib import Path

# --- Ed25519 verification (RFC 8032), pure Python ---------------------------
q = 2**255 - 19
l = 2**252 + 27742317777372353535851937790883648493
d = (-121665 * pow(121666, q - 2, q)) % q
I = pow(2, (q - 1) // 4, q)


def _xrecover(y):
    xx = (y * y - 1) * pow(d * y * y + 1, q - 2, q)
    x = pow(xx, (q + 3) // 8, q)
    if (x * x - xx) % q != 0:
        x = x * I % q
    return x if x % 2 == 0 else q - x


By = 4 * pow(5, q - 2, q) % q
B = (_xrecover(By), By)


def _add(P, Q):
    x1, y1 = P
    x2, y2 = Q
    den = d * x1 * x2 * y1 * y2
    return (
        (x1 * y2 + x2 * y1) * pow(1 + den, q - 2, q) % q,
        (y1 * y2 + x1 * x2) * pow(1 - den, q - 2, q) % q,
    )


def _mul(P, e):
    R = (0, 1)
    while e:
        if e & 1:
            R = _add(R, P)
        P = _add(P, P)
        e >>= 1
    return R


def _point(s):
    y = int.from_bytes(s, "little") & ((1 << 255) - 1)
    x = _xrecover(y)
    if bool(x & 1) != bool(s[31] & 0x80):
        x = q - x
    if (-x * x + y * y - 1 - d * x * x * y * y) % q != 0:
        raise ValueError("point not on curve")
    return (x, y)


def ed25519_verify(sig, msg, pk):
    if len(sig) != 64 or len(pk) != 32:
        return False
    R = _point(sig[:32])
    A = _point(pk)
    S = int.from_bytes(sig[32:], "little")
    if S >= l:
        return False
    h = int.from_bytes(hashlib.sha512(sig[:32] + pk + msg).digest(), "little")
    return _mul(B, S) == _add(R, _mul(A, h))


# --- Attest receipt checks ---------------------------------------------------
def canonical(payload):
    return json.dumps(
        payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str
    ).encode()


def check_receipt(r, key):
    if r.get("public_key") != key:
        return False, "signed by a different key than this issuer"
    payload = r["payload"]
    digest = hashlib.sha256(canonical(payload)).hexdigest()
    if digest != r["payload_hash"]:
        return False, "payload hash mismatch (payload was altered)"
    if payload.get("sequence") != r["sequence"] or payload.get("prev_hash") != r["prev_hash"]:
        return False, "envelope fields disagree with signed payload"
    if payload.get("visit_id") != r["visit_id"]:
        return False, "visit id disagrees with signed payload"
    if payload.get("schema") == "attest.receipt/2":
        # issued_at serializes as "...Z" in the envelope but "+00:00" in the signed
        # payload — compare parsed instants, not strings.
        from datetime import datetime as _dt

        same_instant = (
            _dt.fromisoformat(payload.get("issued_at", ""))
            == _dt.fromisoformat(r["issued_at"])
        )
        if payload.get("receipt_id") != r["id"] or not same_instant:
            return False, "receipt envelope identity disagrees with signed payload"
    elif payload.get("schema") != "attest.receipt/1":
        return False, "unsupported receipt schema"
    if not ed25519_verify(
        base64.b64decode(r["signature"]), bytes.fromhex(r["payload_hash"]), base64.b64decode(key)
    ):
        return False, "signature invalid"
    return True, "ok"


def _member_check(r, allowed):
    if r.get("public_key") not in allowed:
        return False, "signed by a key outside the trusted issuer chain"
    return check_receipt(r, r["public_key"])


def check_bundle(bundle, key):
    """Verify one bundle's original + review chain. Returns (ok, detail, n_reviews).

    ``key`` is either a single pinned issuer key (str) or the trusted-key set
    returned by trusted_keys() — a pack written across a key rotation
    legitimately mixes issuer keys."""
    # ReviewBundle is extra="forbid": honest files carry exactly kind,
    # original, reviews. Any other top-level key (e.g. a forged
    # countersign_status) is unsigned attacker content — fail, don't render it.
    allowed = {key} if isinstance(key, str) else set(key)
    if bundle.get("kind") != "attest.review_bundle/1":
        return False, "unrecognized bundle kind", 0
    extra = set(bundle) - {"kind", "original", "reviews"}
    if extra:
        return False, f"unsigned extra field in bundle: {sorted(extra)[0]}", 0
    original = bundle["original"]
    ok, why = _member_check(original, allowed)
    if not ok:
        return False, f"original: {why}", 0
    prev = original["payload_hash"]
    n = 0
    for n, entry in enumerate(bundle.get("reviews", []), 1):
        r = entry["receipt"]
        ok, why = _member_check(r, allowed)
        if not ok:
            return False, f"review {n}: {why}", n
        if (
            entry["id"] != r["id"]
            or entry["visit_id"] != original["visit_id"]
            or r["visit_id"] != original["visit_id"]
        ):
            return False, f"review {n}: identity does not match original", n
        if entry["revision"] != n or r["sequence"] != n or r["prev_hash"] != prev:
            return False, f"review {n}: sequence or previous hash mismatch", n
        anchor = r["payload"].get("original_receipt") or {}
        if (
            r["payload"].get("record_type") != "review"
            or anchor.get("id") != original["id"]
            or anchor.get("hash") != original["payload_hash"]
        ):
            return False, f"review {n}: not anchored to this original", n
        prev = r["payload_hash"]
    return True, "ok", n + 1


_VERIFIER_TOOLS = ("verify_case.py", "verify_bundle.py", "verify.html", "index.html", "README.txt")


def check_tools(pack_dir, trusted, scope):
    """Enforce the signed verifier_manifest.json pin: the pack's tooling
    members must byte-match the issuer-signed sha256 set. Without it a forged
    always-green verifier script can ride a genuine pack — pack membership
    whitelists names, never bytes. ``scope`` binds the receipt to this pack
    (``visit:{id}`` or ``site:{id}``). Older packs without the member are
    reported, not failed. Returns the pinned tool count or None."""
    vm_path = Path(pack_dir) / "verifier_manifest.json"
    if not vm_path.is_file():
        return None
    try:
        vm = json.loads(vm_path.read_text(encoding="utf-8"))
    except Exception:
        sys.exit("FAIL verifier_manifest.json: not readable JSON")
    payload = vm.get("payload") if isinstance(vm, dict) else None
    if not isinstance(payload, dict) or payload.get("record_type") != "verifier_manifest":
        sys.exit("FAIL verifier_manifest.json: not a verifier_manifest receipt")
    if payload.get("scope") != scope:
        sys.exit("FAIL verifier_manifest.json: signed for a different pack — grafted pin")
    if vm.get("public_key") not in trusted:
        sys.exit("FAIL verifier_manifest.json: signed outside the trusted issuer chain")
    ok, why = check_receipt(vm, vm["public_key"])
    if not ok:
        sys.exit(f"FAIL verifier_manifest.json: {why}")
    tools = payload.get("tools")
    if not isinstance(tools, dict) or not tools:
        sys.exit("FAIL verifier_manifest.json: tools map missing or malformed")
    for name, want in tools.items():
        if (
            not isinstance(name, str)
            or not isinstance(want, str)
            or name not in _VERIFIER_TOOLS
        ):
            sys.exit(f"FAIL verifier_manifest.json: unsafe or unknown member {name!r}")
        fp = Path(pack_dir) / name
        if not fp.is_file():
            sys.exit(f"FAIL {name}: pinned verifier tool missing from the pack")
        if hashlib.sha256(fp.read_bytes()).hexdigest() != want:
            sys.exit(
                f"FAIL {name}: bytes differ from the issuer-signed pin — "
                "a verifier script modified after export cannot be trusted"
            )
    for fp in Path(pack_dir).iterdir():
        # A tool member that ISN'T pinned by the manifest is as suspect as a
        # mismatched one — otherwise the forger just ships a doctored index.html.
        if fp.is_file() and fp.name in _VERIFIER_TOOLS and fp.name not in tools:
            sys.exit(f"FAIL {fp.name}: verifier tooling present but not covered by the signed pin")
    return len(tools)


def _merkle_inclusion(leaf_hex, size, index, path_hex, root_hex):
    """RFC 6962 audit-path verification, stdlib-only (see transparency.py)."""
    try:
        leaf = bytes.fromhex(leaf_hex)
        root_b = bytes.fromhex(root_hex)
    except (TypeError, ValueError):
        return False
    if not isinstance(size, int) or not isinstance(index, int):
        return False
    if index < 0 or index >= size or size < 1:
        return False
    r = hashlib.sha256(b"\x00" + leaf).digest()
    if size == 1:
        return not path_hex and r == root_b
    fn, sn = index, size - 1
    for ph in path_hex:
        try:
            p = bytes.fromhex(ph)
        except (TypeError, ValueError):
            return False
        if len(p) != 32 or sn == 0:
            return False
        if (fn & 1) or fn == sn:
            r = hashlib.sha256(b"\x01" + p + r).digest()
            while fn and not (fn & 1):
                fn >>= 1
                sn >>= 1
        else:
            r = hashlib.sha256(b"\x01" + r + p).digest()
        fn >>= 1
        sn >>= 1
    return sn == 0 and r == root_b


def check_log(pack_dir, trusted, receipts):
    """Verify the pack's transparency checkpoint: ``log_checkpoint.json``
    carries a signed Merkle Tree Head (a ``log_checkpoint`` receipt) plus an
    RFC 6962 inclusion path for every receipts-table member the pack holds —
    'this receipt was in the deployment's published log' becomes provable in
    O(log n) instead of trusting enumeration. Review-chain entries are not
    leaves: they anchor to the original's hash (verified by check_bundle), so
    the proven original transitively commits them. Absent → a pre-checkpoint
    pack, reported not failed; present → every listed receipt must carry a
    working proof, so a receipt never committed to the log fails closed.
    Returns (proven_count, tree_size) or None."""
    cp_path = Path(pack_dir) / "log_checkpoint.json"
    if not cp_path.is_file():
        return None
    try:
        doc = json.loads(cp_path.read_text(encoding="utf-8"))
    except Exception:
        sys.exit("FAIL log_checkpoint.json: not readable JSON")
    cp = doc.get("checkpoint") if isinstance(doc, dict) else None
    proofs = doc.get("proofs") if isinstance(doc, dict) else None
    if not isinstance(cp, dict) or not isinstance(proofs, dict):
        sys.exit("FAIL log_checkpoint.json: malformed checkpoint document")
    payload = cp.get("payload")
    if not isinstance(payload, dict) or payload.get("record_type") != "log_checkpoint":
        sys.exit("FAIL log_checkpoint.json: not a log_checkpoint receipt")
    if cp.get("public_key") not in trusted:
        sys.exit("FAIL log_checkpoint.json: signed outside the trusted issuer chain")
    ok, why = check_receipt(cp, cp["public_key"])
    if not ok:
        sys.exit(f"FAIL log_checkpoint.json: {why}")
    size = payload.get("tree_size")
    root_hex = payload.get("root_sha256")
    if not isinstance(size, int) or size < 1 or not isinstance(root_hex, str):
        sys.exit("FAIL log_checkpoint.json: malformed tree head")
    proven = 0
    for r in receipts:
        ph = r.get("payload_hash") if isinstance(r, dict) else None
        # Only issuer-lineage receipts owe proofs: a foreign-signed pool
        # entry is inert (it can't join the trust walk) and never claimed
        # log membership — requiring its proof would let a graft kill packs.
        if not ph or r.get("public_key") not in trusted:
            continue
        # The checkpoint receipt IS the signed tree head — it cannot sit
        # inside its own tree, and needs no proof.
        if ph == cp.get("payload_hash"):
            continue
        p = proofs.get(ph)
        if not isinstance(p, dict):
            sys.exit(
                f"FAIL log_checkpoint.json: receipt {r.get('id') or ph[:16]} has no "
                "inclusion proof — never committed to the deployment log"
            )
        if not _merkle_inclusion(ph, size, p.get("leaf_index", -1), p.get("path") or [], root_hex):
            sys.exit(
                f"FAIL log_checkpoint.json: inclusion proof for receipt "
                f"{r.get('id') or ph[:16]} does not reach the signed tree head"
            )
        proven += 1
    return proven, size


def check_media(bundle, media_dir, withheld=None):
    """Match each evidence media digest to a file under media_dir.

    ``withheld`` lists digests deliberately redacted from the pack: they are
    reported as withheld, not as missing. A digest that matches neither a file
    nor the withheld list fails. Returns (checked, withheld_count, bad_digest).
    """
    withheld = set(withheld or [])
    checked = held = 0
    signed = {
        e.get("media_sha256")
        for e in bundle["original"]["payload"].get("evidence", [])
        if e.get("media_sha256")
    }
    for e in bundle["original"]["payload"].get("evidence", []):
        digest = e.get("media_sha256")
        if not digest:
            continue
        for p in media_dir.rglob("*"):
            if p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest() == digest:
                checked += 1
                break
        else:
            if digest in withheld:
                held += 1
                continue
            return checked, held, digest
    if media_dir.exists():
        # A media file whose bytes don't hash to a signed digest is smuggled
        # content riding inside a "VERIFIED" pack — fail it, don't skip it.
        for p in sorted(media_dir.rglob("*")):
            if p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest() not in signed:
                return checked, held, f"smuggled:{p.name}"
    return checked, held, None


def redaction_for(bundle, pack_dir="."):
    """Read redaction.json inside pack_dir, if present. Returns the withheld
    digests or None. Fails closed: a redaction file naming digests absent from
    the signed evidence is itself suspicious."""
    marker = Path(pack_dir) / "redaction.json"
    if not marker.is_file():
        return None
    data = json.loads(marker.read_text(encoding="utf-8"))
    digests = set(data.get("withheld_digests", []))
    signed = {
        e.get("media_sha256")
        for e in bundle["original"]["payload"].get("evidence", [])
        if e.get("media_sha256")
    }
    if not digests <= signed:
        raise ValueError("redaction.json lists digests not in the signed evidence")
    return digests


def check_manifest(manifest, key):
    """If the manifest carries a signature_receipt, verify it: the export was
    signed at pack time and names exactly which receipt hashes it carries —
    a pack that drops or swaps a record fails here, not just on a missing
    file. Older packs without a signature are reported, not failed. ``key``
    is a single pinned key or the trusted_keys() set — the signature receipt
    must verify under a key inside the trusted issuer chain."""
    sig = manifest.get("signature_receipt")
    if sig is None:
        return True, "unsigned manifest (pre-signature pack)"
    allowed = {key} if isinstance(key, str) else set(key)
    ok, why = _member_check(sig, allowed)
    if not ok:
        return False, f"manifest signature: {why}"
    core = {k: v for k, v in manifest.items() if k != "signature_receipt"}
    digest = hashlib.sha256(canonical(core)).hexdigest()
    if digest != sig["payload"].get("manifest_sha256"):
        return False, "manifest content hash mismatch (manifest was altered)"
    signed_hashes = sig["payload"].get("receipt_hashes", {})
    # A malformed visit entry must fail the comparison, never raise out of
    # the verifier — the unsigned manifest cannot name a trusted shape.
    listed = {
        v["visit_id"]: v["payload_hash"]
        for v in manifest.get("visits", [])
        if isinstance(v, dict) and "visit_id" in v and "payload_hash" in v
    }
    if listed != signed_hashes:
        return False, "manifest visit list disagrees with the signed export"
    return True, f"export signed: {len(listed)} record(s)"


def _adoption_consent(receipts, rotation, new_key):
    """Whether the SUCCESSOR key countersigned the rotation via a
    key_adoption receipt naming it (id + payload hash). A retiring key's
    endorsement is self-serve — any key can claim any successor — so consent
    is what separates a real handoff from a grafted "predecessor"."""
    for r in receipts:
        p = r.get("payload", {})
        link = p.get("rotation_receipt") or {}
        if (
            p.get("record_type") == "key_adoption"
            and link.get("id") == rotation.get("id")
            and link.get("hash") == rotation.get("payload_hash")
            and r.get("public_key") == new_key
        ):
            ok, _ = check_receipt(r, new_key)
            if ok:
                return True
    return False


def trusted_keys(issuer_key, rotation_receipts, max_hops=32):
    """The keys a pack verification may trust: the manifest issuer plus every
    ancestor reachable through signed key_rotation receipts. Each hop must be
    a valid receipt signed by the retiring key endorsing its successor AND
    countersigned by that successor via key_adoption — a forged or
    unconsented rotation never lands in the set."""
    trusted = {issuer_key}
    cur = issuer_key
    for _ in range(max_hops):
        nxt = None
        for r in rotation_receipts:
            p = r.get("payload", {})
            if (
                p.get("record_type") == "key_rotation"
                and p.get("new_key") == cur
                and r.get("public_key") == p.get("previous_key")
            ):
                ok, _ = check_receipt(r, r["public_key"])
                if ok and _adoption_consent(rotation_receipts, r, cur):
                    nxt = p["previous_key"]
                    break
        if nxt is None:
            break
        cur = nxt
        trusted.add(cur)
    return trusted


def descendant_keys(root_key, rotation_receipts, max_hops=32):
    """The mirror walk for single-visit bundles: reviews append forward in
    time, so a bundle legitimately carries keys AFTER its original — every
    successor reachable through signed rotations. Each hop needs BOTH
    signatures: the retiring key's endorsement and the successor's
    key_adoption consent — an orphaned rotation (crashed before adoption)
    is a dead branch, not a trusted descendant."""
    trusted = {root_key}
    cur = root_key
    for _ in range(max_hops):
        nxt = None
        for r in rotation_receipts:
            p = r.get("payload", {})
            if (
                p.get("record_type") == "key_rotation"
                and p.get("previous_key") == cur
                and r.get("public_key") == cur
            ):
                ok, _ = check_receipt(r, cur)
                if ok and _adoption_consent(rotation_receipts, r, p["new_key"]):
                    nxt = p["new_key"]
                    break
        if nxt is None:
            break
        cur = nxt
        trusted.add(cur)
    return trusted


def _lineage_root(issuer_key, key_receipts):
    """The oldest ancestor the consented pivots reach from ``issuer_key`` —
    where a revocation-authority walk must seed. In a pack the receipt pool
    is attacker-controlled, so pool position can never confer authority:
    a self-signed key_revocation at sequence 0 must not make itself the
    root. Anchoring inside the verified lineage keeps that graft inert."""
    cur = issuer_key
    for _ in range(32):
        nxt = None
        for r in key_receipts:
            p = r.get("payload", {})
            if (
                p.get("record_type") == "key_rotation"
                and p.get("new_key") == cur
                and r.get("public_key") == p.get("previous_key")
            ):
                ok, _ = check_receipt(r, r["public_key"])
                if ok and _adoption_consent(key_receipts, r, cur):
                    nxt = p["previous_key"]
                    break
        if nxt is None:
            break
        cur = nxt
    return cur


def revoked_keys(key_receipts, issuer_key=None):
    """Key -> suspect_after ISO for valid key_revocation receipts signed by
    the in-effect issuer at their position. Only the live key can revoke —
    a retired key revoking its successor would let a compromised key smear
    the healthy one, and position alone can't name the tip: a forged
    high-sequence revocation would make itself the tip and self-authorize.

    ``issuer_key`` anchors the walk at the lineage root — pass it always in
    pack verification, where the pool is attacker-controlled. A revocation
    also counts only for a key the lineage has already produced: a retired
    key smearing a successor that hasn't pivoted in yet is just as inert
    as a foreign key."""
    ordered = sorted(key_receipts, key=lambda x: x.get("sequence", 0))
    revoked = {}
    if issuer_key is not None:
        in_effect = _lineage_root(issuer_key, ordered)
    else:
        in_effect = None
    seen = {in_effect} if in_effect is not None else set()
    for r in ordered:
        ok, _ = check_receipt(r, in_effect or r.get("public_key"))
        if not ok:
            continue
        if in_effect is None:
            in_effect = r.get("public_key")
        seen.add(r.get("public_key"))
        p = r.get("payload", {})
        if (
            p.get("record_type") == "key_rotation"
            and p.get("previous_key") == in_effect
            and p.get("new_key")
            and _adoption_consent(ordered, r, p["new_key"])
        ):
            in_effect = p["new_key"]
            seen.add(in_effect)
            continue
        if (
            p.get("record_type") == "key_revocation"
            and p.get("revoked_key") in seen
            and r.get("public_key") == in_effect
        ):
            revoked[p["revoked_key"]] = p.get("suspect_after") or ""
    return revoked


def suspect_records(receipts, revoked):
    """Receipts signed by a revoked key inside its declared suspect window —
    cryptographically valid, annotated suspect. Integrity never depends on
    this; it's what a compromised key's history deserves."""
    from datetime import UTC, datetime

    def _instant(s):
        try:
            at = s if isinstance(s, datetime) else datetime.fromisoformat(str(s).replace("Z", "+00:00"))
        except (TypeError, ValueError):
            return None
        # Naive spellings read as UTC: a forged or sloppy timestamp must not
        # crash the comparison, only compare conservatively.
        return at.replace(tzinfo=UTC) if at.tzinfo is None else at

    out = []
    for r in receipts:
        if not isinstance(r, dict):
            continue
        after = _instant(revoked.get(r.get("public_key"), ""))
        at = _instant(r.get("issued_at", ""))
        if after is not None and at is not None and at > after:
            out.append(r)
    return out


def load_issuer_doc(path):
    """Load an attest.issuer/1 discovery document — the file written by
    `attest issuer --out` or fetched from /.well-known/attest-issuer.json.
    Returns (issuer_key, key_receipts); anything else fails closed. The doc
    pins verification to a DEPLOYMENT rather than a key fingerprint, and its
    signed lifecycle receipts extend trust to packs exported before a
    rotation. Its authenticity is only as strong as how you got the file —
    --key remains the out-of-band pin."""
    try:
        doc = json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception as exc:
        sys.exit(f"FAIL issuer document unreadable: {exc}")
    if (
        not isinstance(doc, dict)
        or doc.get("schema") != "attest.issuer/1"
        or not isinstance(doc.get("issuer_key"), str)
        or not doc["issuer_key"]
    ):
        sys.exit("FAIL issuer document is not attest.issuer/1")
    receipts = doc.get("key_receipts") or []
    if not isinstance(receipts, list):
        sys.exit("FAIL issuer document: key_receipts is not a list")
    return doc["issuer_key"], receipts
def main():
    args = sys.argv[1:]
    key = None
    issuer_receipts = []
    if "--key" in args:
        i = args.index("--key")
        if i + 1 >= len(args):
            sys.exit("FAIL --key requires a base64 public key value")
        key = args[i + 1]
        del args[i : i + 2]
    if "--issuer" in args:
        i = args.index("--issuer")
        if i + 1 >= len(args):
            sys.exit("FAIL --issuer requires an issuer-document path")
        if key is not None:
            sys.exit("FAIL pass --key or --issuer, not both")
        key, issuer_receipts = load_issuer_doc(args[i + 1])
        del args[i : i + 2]
    bundle = json.loads(Path(args[0]).read_text(encoding="utf-8"))
    pack_dir = Path(args[0]).resolve().parent
    key = key or bundle["original"]["public_key"]
    # Reviews appended after a key rotation verify under the successor —
    # legitimate only through the signed rotation links in key_rotations.json
    # (or an --issuer document's own lifecycle receipts: they pin this bundle
    # to a DEPLOYMENT and bridge exports made before a rotation).
    # Revocation receipts ride the same file: the overlay annotates suspect
    # windows without touching the integrity verdict.
    trusted = {key}
    rotations = list(issuer_receipts)
    pack_lifecycle = []
    rot_path = pack_dir / "key_rotations.json"
    if rot_path.is_file():
        try:
            rj = json.loads(rot_path.read_text(encoding="utf-8"))
            extra = rj.get("rotations") if isinstance(rj, dict) else None
        except Exception:
            extra = None
        if not isinstance(extra, list):
            sys.exit("FAIL key_rotations.json: malformed")
        rotations += extra
        pack_lifecycle = extra
    if rotations:
        trusted = trusted_keys(key, rotations) | descendant_keys(key, rotations)
    revoked = revoked_keys(rotations, key)
    ok, why, n = check_bundle(bundle, trusted)
    if not ok:
        sys.exit(f"FAIL {why}")
    try:
        withheld = redaction_for(bundle, pack_dir)
    except ValueError as exc:
        sys.exit(f"FAIL {exc}")
    checked, held, bad = check_media(bundle, pack_dir / "media", withheld)
    if bad:
        if str(bad).startswith("smuggled:"):
            sys.exit(f"FAIL media file not named by the signed evidence: {bad[9:]}")
        sys.exit(f"FAIL media digest not found in pack: {bad[:16]}...")
    # Fail closed on files the pack format doesn't name — but only when the
    # directory looks like an extracted pack (README/media/pack pages present).
    # A bare bundle.json shared alone has no pack around it to smuggle into.
    allowed_top = {
        "bundle.json",
        "README.txt",
        "verify_bundle.py",
        "verify.html",
        "index.html",
        "redaction.json",
        "key_rotations.json",
        "verifier_manifest.json",
        "log_checkpoint.json",
    }
    markers = ("README.txt", "media", "verify.html", "index.html")
    if any((pack_dir / m).exists() for m in markers):
        for p in sorted(pack_dir.iterdir()):
            if p.is_file() and p.name not in allowed_top:
                sys.exit(f"FAIL {p.name}: present but not part of the pack format")
            if p.is_dir() and p.name != "media":
                sys.exit(f"FAIL {p.name}/: directory not part of the pack format")
    pinned_tools = check_tools(pack_dir, trusted, f'visit:{bundle["original"]["visit_id"]}')
    # Transparency checkpoint: the log's leaves are the receipts-table chain
    # — originals, lifecycle, manifests. Review-chain entries anchor to the
    # original's hash (verified above) instead of sitting in the log, so the
    # proven original transitively commits them.
    logged = check_log(
        pack_dir,
        trusted,
        [bundle["original"]]
        + pack_lifecycle
        + ([json.loads((pack_dir / "verifier_manifest.json").read_text(encoding="utf-8"))]
           if (pack_dir / "verifier_manifest.json").is_file() else []),
    )
    redact_note = f", {held} withheld by redaction" if held else ""
    print(f"OK: {n} receipt(s) verified; {checked} media digests matched{redact_note}.")
    if len(trusted) > 1:
        print(f"    ({len(trusted)} issuer keys linked via the signed rotation chain)")
    suspect = suspect_records(
        [bundle["original"]] + [e["receipt"] for e in bundle.get("reviews", [])], revoked)
    if suspect:
        print(f"    ({len(suspect)} record(s) signed by a revoked issuer inside its suspect window)")
    # A rotation signed by a key later declared suspect means the handoff
    # itself may be attacker-authored — the lineage carries the doubt.
    pivots = suspect_records(rotations, revoked)
    if pivots:
        print(f"    ({len(pivots)} key-lifecycle receipt(s) signed inside a suspect window —")
        print("     the trust pivot itself inherits the doubt)")
    if issuer_receipts:
        print(f"    (pinned via a deployment issuer document — {len(issuer_receipts)} "
              "lifecycle receipt(s); its authenticity rides on how it reached you)")
    if pinned_tools:
        print(f"    ({pinned_tools} verifier tool(s) pinned by issuer-signed manifest — "
              "the pack's own scripts are proven unmodified)")
    if logged:
        print(f"    ({logged[0]} receipt(s) proven inside the deployment's transparency"
              f" log at checkpoint size {logged[1]})")
    print("Signature proves record integrity under the issuer key - not identity,")
    print("attendance, or absence.")


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as exc:
        # Never die with a traceback — the vocabulary of this tool is OK/FAIL.
        sys.exit(f"FAIL verifier error: {exc}")
