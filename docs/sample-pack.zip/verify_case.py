#!/usr/bin/env python3
"""Verify Attest records offline. Stdlib only — no pip, no attest install.

Checks: payload sha256, envelope/payload agreement, Ed25519 signatures,
revision ordering, and anchoring to the original receipt. Media digests are
checked against files inside the pack.
"""
import base64
import hashlib
import json
import sys
from pathlib import Path

# --- Ed25519 verification (RFC 8032), pure Python ---------------------------
q = 2**255 - 19
l = 2**252 + 27742317777372353535851937790883648493
d = (-121665 * pow(121666, q - 2, q)) % q
I = pow(2, (q - 1) // 4, q)


def _xrecover(y):
    xx = (y * y - 1) * pow(d * y * y + 1, q - 2, q)
    x = pow(xx, (q + 3) // 8, q)
    if (x * x - xx) % q != 0:
        x = x * I % q
    return x if x % 2 == 0 else q - x


By = 4 * pow(5, q - 2, q) % q
B = (_xrecover(By), By)


def _add(P, Q):
    x1, y1 = P
    x2, y2 = Q
    den = d * x1 * x2 * y1 * y2
    return (
        (x1 * y2 + x2 * y1) * pow(1 + den, q - 2, q) % q,
        (y1 * y2 + x1 * x2) * pow(1 - den, q - 2, q) % q,
    )


def _mul(P, e):
    R = (0, 1)
    while e:
        if e & 1:
            R = _add(R, P)
        P = _add(P, P)
        e >>= 1
    return R


def _point(s):
    y = int.from_bytes(s, "little") & ((1 << 255) - 1)
    x = _xrecover(y)
    if bool(x & 1) != bool(s[31] & 0x80):
        x = q - x
    if (-x * x + y * y - 1 - d * x * x * y * y) % q != 0:
        raise ValueError("point not on curve")
    return (x, y)


def ed25519_verify(sig, msg, pk):
    if len(sig) != 64 or len(pk) != 32:
        return False
    R = _point(sig[:32])
    A = _point(pk)
    S = int.from_bytes(sig[32:], "little")
    if S >= l:
        return False
    h = int.from_bytes(hashlib.sha512(sig[:32] + pk + msg).digest(), "little")
    return _mul(B, S) == _add(R, _mul(A, h))


# --- Attest receipt checks ---------------------------------------------------
def canonical(payload):
    return json.dumps(
        payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str
    ).encode()


def check_receipt(r, key):
    if r.get("public_key") != key:
        return False, "signed by a different key than this issuer"
    payload = r["payload"]
    digest = hashlib.sha256(canonical(payload)).hexdigest()
    if digest != r["payload_hash"]:
        return False, "payload hash mismatch (payload was altered)"
    if payload.get("sequence") != r["sequence"] or payload.get("prev_hash") != r["prev_hash"]:
        return False, "envelope fields disagree with signed payload"
    if payload.get("visit_id") != r["visit_id"]:
        return False, "visit id disagrees with signed payload"
    if payload.get("schema") == "attest.receipt/2":
        # issued_at serializes as "...Z" in the envelope but "+00:00" in the signed
        # payload — compare parsed instants, not strings.
        from datetime import datetime as _dt

        same_instant = (
            _dt.fromisoformat(payload.get("issued_at", ""))
            == _dt.fromisoformat(r["issued_at"])
        )
        if payload.get("receipt_id") != r["id"] or not same_instant:
            return False, "receipt envelope identity disagrees with signed payload"
    elif payload.get("schema") != "attest.receipt/1":
        return False, "unsupported receipt schema"
    if not ed25519_verify(
        base64.b64decode(r["signature"]), bytes.fromhex(r["payload_hash"]), base64.b64decode(key)
    ):
        return False, "signature invalid"
    return True, "ok"


def check_bundle(bundle, key):
    """Verify one bundle's original + review chain. Returns (ok, detail, n_reviews)."""
    # ReviewBundle is extra="forbid": honest files carry exactly kind,
    # original, reviews. Any other top-level key (e.g. a forged
    # countersign_status) is unsigned attacker content — fail, don't render it.
    if bundle.get("kind") != "attest.review_bundle/1":
        return False, "unrecognized bundle kind", 0
    extra = set(bundle) - {"kind", "original", "reviews"}
    if extra:
        return False, f"unsigned extra field in bundle: {sorted(extra)[0]}", 0
    original = bundle["original"]
    ok, why = check_receipt(original, key)
    if not ok:
        return False, f"original: {why}", 0
    prev = original["payload_hash"]
    n = 0
    for n, entry in enumerate(bundle.get("reviews", []), 1):
        r = entry["receipt"]
        ok, why = check_receipt(r, key)
        if not ok:
            return False, f"review {n}: {why}", n
        if (
            entry["id"] != r["id"]
            or entry["visit_id"] != original["visit_id"]
            or r["visit_id"] != original["visit_id"]
        ):
            return False, f"review {n}: identity does not match original", n
        if entry["revision"] != n or r["sequence"] != n or r["prev_hash"] != prev:
            return False, f"review {n}: sequence or previous hash mismatch", n
        anchor = r["payload"].get("original_receipt") or {}
        if (
            r["payload"].get("record_type") != "review"
            or anchor.get("id") != original["id"]
            or anchor.get("hash") != original["payload_hash"]
        ):
            return False, f"review {n}: not anchored to this original", n
        prev = r["payload_hash"]
    return True, "ok", n + 1


def check_media(bundle, media_dir, withheld=None):
    """Match each evidence media digest to a file under media_dir.

    ``withheld`` lists digests deliberately redacted from the pack: they are
    reported as withheld, not as missing. A digest that matches neither a file
    nor the withheld list fails. Returns (checked, withheld_count, bad_digest).
    """
    withheld = set(withheld or [])
    checked = held = 0
    signed = {
        e.get("media_sha256")
        for e in bundle["original"]["payload"].get("evidence", [])
        if e.get("media_sha256")
    }
    for e in bundle["original"]["payload"].get("evidence", []):
        digest = e.get("media_sha256")
        if not digest:
            continue
        for p in media_dir.rglob("*"):
            if p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest() == digest:
                checked += 1
                break
        else:
            if digest in withheld:
                held += 1
                continue
            return checked, held, digest
    if media_dir.exists():
        # A media file whose bytes don't hash to a signed digest is smuggled
        # content riding inside a "VERIFIED" pack — fail it, don't skip it.
        for p in sorted(media_dir.rglob("*")):
            if p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest() not in signed:
                return checked, held, f"smuggled:{p.name}"
    return checked, held, None


def redaction_for(bundle, pack_dir="."):
    """Read redaction.json inside pack_dir, if present. Returns the withheld
    digests or None. Fails closed: a redaction file naming digests absent from
    the signed evidence is itself suspicious."""
    marker = Path(pack_dir) / "redaction.json"
    if not marker.is_file():
        return None
    data = json.loads(marker.read_text(encoding="utf-8"))
    digests = set(data.get("withheld_digests", []))
    signed = {
        e.get("media_sha256")
        for e in bundle["original"]["payload"].get("evidence", [])
        if e.get("media_sha256")
    }
    if not digests <= signed:
        raise ValueError("redaction.json lists digests not in the signed evidence")
    return digests


def check_manifest(manifest, key):
    """If the manifest carries a signature_receipt, verify it: the export was
    signed at pack time and names exactly which receipt hashes it carries —
    a pack that drops or swaps a record fails here, not just on a missing
    file. Older packs without a signature are reported, not failed."""
    sig = manifest.get("signature_receipt")
    if sig is None:
        return True, "unsigned manifest (pre-signature pack)"
    ok, why = check_receipt(sig, key)
    if not ok:
        return False, f"manifest signature: {why}"
    core = {k: v for k, v in manifest.items() if k != "signature_receipt"}
    digest = hashlib.sha256(canonical(core)).hexdigest()
    if digest != sig["payload"].get("manifest_sha256"):
        return False, "manifest content hash mismatch (manifest was altered)"
    signed_hashes = sig["payload"].get("receipt_hashes", {})
    listed = {v["visit_id"]: v["payload_hash"] for v in manifest.get("visits", [])}
    if listed != signed_hashes:
        return False, "manifest visit list disagrees with the signed export"
    return True, f"export signed: {len(listed)} record(s)"
def main():
    args = sys.argv[1:]
    key = None
    if "--key" in args:
        i = args.index("--key")
        if i + 1 >= len(args):
            sys.exit("FAIL --key requires a base64 public key value")
        key = args[i + 1]
        del args[i : i + 2]
    root = Path(args[0]) if args else Path(".")
    try:
        manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    except Exception as exc:
        sys.exit(f"FAIL manifest.json unreadable: {exc}")
    declared = manifest.get("issuer_key")
    if not declared:
        sys.exit("FAIL manifest: missing issuer_key")
    if key is not None and declared != key:
        sys.exit("FAIL manifest: issuer_key disagrees with the pinned --key")
    # Without --key the issuer is self-declared by the pack — the signatures
    # still verify, but 'who signed' is only as trustworthy as the source of
    # this file. Pin --key to rule out a whole-pack forgery under another key.
    key = key or declared
    if manifest.get("schema") != "attest.case-pack/1":
        sys.exit(f"FAIL manifest: unsupported schema {manifest.get('schema')!r}")
    visits = manifest.get("visits")
    if not isinstance(visits, list):
        sys.exit("FAIL manifest: visits is missing or not a list")
    failed = 0
    listed_vids = set()
    for v in visits:
        vid = v.get("visit_id", "?")
        listed_vids.add(vid)
        try:
            bundle = json.loads((root / "visits" / vid / "bundle.json").read_text(encoding="utf-8"))
        except Exception as exc:
            print(f"FAIL {vid}: bundle listed but missing or unreadable ({exc})")
            failed += 1
            continue
        ok, why, n = check_bundle(bundle, key)
        if not ok:
            print(f"FAIL {vid}: {why}")
            failed += 1
            continue
        if bundle["original"]["payload_hash"] != v.get("payload_hash"):
            print(f"FAIL {vid}: manifest hash disagrees with signed original")
            failed += 1
            continue
        vdir = root / "visits" / vid
        try:
            withheld = redaction_for(bundle, vdir)
        except ValueError as exc:
            print(f"FAIL {vid}: {exc}")
            failed += 1
            continue
        if set(v.get("media_withheld", [])) != set(withheld or []):
            print(f"FAIL {vid}: manifest redaction list disagrees with redaction.json")
            failed += 1
            continue
        checked, held, bad = check_media(bundle, vdir / "media", withheld)
        if bad:
            if str(bad).startswith("smuggled:"):
                print(f"FAIL {vid}: media file not named by the signed evidence: {bad[9:]}")
            else:
                print(f"FAIL {vid}: media digest not found: {bad[:16]}...")
            failed += 1
            continue
        redact_note = f", {held} withheld" if held else ""
        cs = (v.get("countersign") or {}).get("state", "?")
        print(f"OK   {vid}: {v.get('state', '?')} — {cs}"
              f" ({n} receipt(s), {checked} media digest(s){redact_note})")
    for a in manifest.get("attestations", []):
        rid = a.get("receipt_id", "?")
        apath = root / "attestations" / f"{rid}.json"
        if not apath.exists():
            print(f"FAIL attestation {rid}: manifest lists it but the file is missing")
            failed += 1
            continue
        try:
            ar = json.loads(apath.read_text(encoding="utf-8"))
        except Exception as exc:
            print(f"FAIL attestation {rid}: unreadable ({exc})")
            failed += 1
            continue
        aok, awhy = check_receipt(ar, key)
        if not aok:
            print(f"FAIL attestation {rid}: {awhy}")
            failed += 1
        elif ar["payload_hash"] != a.get("payload_hash") or ar["visit_id"] != a.get("visit_id"):
            print(f"FAIL attestation {rid}: disagrees with the signed manifest")
            failed += 1
        else:
            print(f"OK   attestation {a.get('record_type') or 'record'} ({rid[:20]}...)")
    adir = root / "attestations"
    if adir.exists():
        listed = {f"{a.get('receipt_id')}.json" for a in manifest.get("attestations", [])}
        extra = {p.name for p in adir.glob("*.json")} - listed
        if extra:
            print(f"FAIL {len(extra)} attestation file(s) present but not in the signed manifest")
            failed += 1
    vdir = root / "visits"
    if vdir.exists():
        extra_v = {p.name for p in vdir.iterdir() if p.is_dir()} - listed_vids
        if extra_v:
            print(f"FAIL {len(extra_v)} visit dir(s) present but not in the signed manifest")
            failed += 1
    # Fail closed on any file the pack format doesn't name — a smuggled
    # top-level file or extra member inside a visit dir would otherwise ride
    # inside a "VERIFIED" pack. Media members are digest-checked by
    # check_media against the signed evidence.
    allowed_top = {"manifest.json", "README.txt", "verify_case.py", "verify.html", "index.html"}
    for p in sorted(root.iterdir()):
        if p.is_file() and p.name not in allowed_top:
            print(f"FAIL {p.name}: present but not in the signed manifest")
            failed += 1
        elif p.is_dir() and p.name not in ("visits", "attestations"):
            print(f"FAIL {p.name}/: directory not in the signed manifest")
            failed += 1
    if vdir.exists():
        for vd in sorted(p for p in vdir.iterdir() if p.is_dir()):
            for p in sorted(vd.iterdir()):
                if p.is_file() and p.name not in ("bundle.json", "redaction.json"):
                    print(f"FAIL {vd.name}/{p.name}: present but not in the signed manifest")
                    failed += 1
                elif p.is_dir() and p.name != "media":
                    print(f"FAIL {vd.name}/{p.name}/: directory not in the signed manifest")
                    failed += 1
    mok, mwhy = check_manifest(manifest, key)
    print(f"{'OK  ' if mok else 'FAIL'} manifest: {mwhy}")
    if not mok:
        failed += 1
    if failed:
        sys.exit(f"{failed} record(s) failed verification")
    print(f"OK: {len(visits)} visit records verified under issuer key")
    print(f"    {key[:16]}...")
    if declared == key and "--key" not in sys.argv:
        print("    (issuer self-declared by the pack — pass --key to pin it)")
    print("Integrity only — not identity, attendance, or absence.")


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as exc:
        # Never die with a traceback — the vocabulary of this tool is OK/FAIL.
        sys.exit(f"FAIL verifier error: {exc}")
